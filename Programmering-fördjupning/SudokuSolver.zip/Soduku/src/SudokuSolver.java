
public class SudokuSolver {

	/**
	 * Skapar ett grafiskt anv�ndargr�nsnitt f�r sudokul�saren.
	 * @param args
	 */
	public static void main(String[] args) {
		SudokuSolverGUI gui = new SudokuSolverGUI();
	}

}
