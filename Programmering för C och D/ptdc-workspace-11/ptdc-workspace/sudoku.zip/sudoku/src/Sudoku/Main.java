package Sudoku;
/**
 * 
 * @author Rickard Johansson & Thomas Strahl
 *
 */
public class Main {
	public static void main(String[] args) {
		new SudokuGUI();

		
		
		
		
			
	
	}

}
